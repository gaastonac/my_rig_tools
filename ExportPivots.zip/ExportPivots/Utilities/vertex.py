import pymel.core as pm
import json
import os 

def createRootFolders():
    version=pm.about(version=True)
    parentDir = "{}/maya/{}/scripts/{}/".format(os.getenv("HOME"),version,"ExportPivots") 
    directory = "Libraries"
    path = os.path.join(parentDir,directory)
    libraryPath = "{}/pivotsExported".format(path)

#------------------Crear carpeta padre e hijos si no existen---------------------------#
    if not os.path.exists("{}{}".format(parentDir,directory)):          
        print "Path doesnt exists, it will be created"
        os.mkdir("{}{}".format(parentDir,directory))
            
    if ".json" not in libraryPath:
        libraryPath = "{}.json".format(libraryPath) 
    
    if not os.path.exists(libraryPath):
        tempdic = {}
        with open(libraryPath, "w") as tempJsonFile:        
            json.dump(tempdic,tempJsonFile,indent=2)
    return libraryPath  
#createRootFolders()
#------------------Actualizar Json file con la info-------------------------------------#

def exportInformation(namePivot,function,*args):
    def updateJsonFile(dataToExport,fileName,*args):

        with open(fileName) as f:
            tempDic = json.load(f)
            tempDic.update(dataToExport)

        with open(fileName, "w") as jsonFile:
            json.dump(tempDic,jsonFile,indent=2)

    def removeJsonFile(dataToRemove,fileName,*args):
        with open(fileName) as f:
            tempDic = json.load(f)
            tempDic.pop(dataToRemove)

        with open(fileName, "w") as jsonFile:
            json.dump(tempDic,jsonFile,indent=2)

    def getDicShape(*args):

         
        if len(pm.ls(sl=True))!= 0:
            init_sel = pm.ls(sl=True)
            filterVertex=pm.filterExpand(init_sel,sm=31)
        else:
            showError()

                  
        #PosCvs=[tuple(pm.pointPosition(shape.cv[i],world=True))for i in range(0,shape.numCVs())]    

        temp_Dic={namePivot:filterVertex}

        return temp_Dic

    if function == "Add":
        updateJsonFile(getDicShape(),createRootFolders())
        print "{} added succesfully".format(namePivot)
    elif function == "Remove":
        removeJsonFile(namePivot,createRootFolders())
        print "{} remove".format(namePivot)

def loadVertexInfo():    
    def readJsonFile(fileName,*args):
        with open(fileName) as f:
            tempDic=json.load(f)
        return tempDic

    dicArg=readJsonFile(createRootFolders())
    keys=dicArg.keys()
    base_grp=pm.createNode("transform",n="Guides")
    for key in keys:
        try:
            pm.select(dicArg[key])
            result=pm.cluster(name=key)[1]
            pm.select(clear=True)
            base_grp.addChild(result)
        except:
            pass

def showError():
    raise Exception("Please select at least one Vertex")
    return
