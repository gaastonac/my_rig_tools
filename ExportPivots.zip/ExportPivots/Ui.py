from PySide2 import  QtWidgets as qg, QtCore as qc
import Utilities.vertex as utils ;reload(utils)
dialog=None

#----------------------------------------------------------------------------------#

class baseWindow(qg.QDialog):
    def __init__(self):
        qg.QDialog.__init__(self)
        self.setWindowFlags(qc.Qt.WindowStaysOnTopHint)
        self.setWindowTitle("Exporter")
        self.setFixedHeight(150)
        self.setFixedWidth(320)
        self.setModal(False)

        self.setLayout(qg.QVBoxLayout())
        self.layout().setContentsMargins(5,5,5,5)
        self.layout().setSpacing(20)
        self.layout().setAlignment(qc.Qt.AlignTop)

#RENAME widget
        showObject_widget = self.createBasicWidget(spacing=10)
        self.layout().addWidget(showObject_widget)

#-----------------Main Layout----------------------#
        main_layout  = qg.QVBoxLayout()
        showObject_widget.layout().addLayout(main_layout)      

#-----------------Named Lain Edit----------------------#
        named_layout = qg.QVBoxLayout()
        main_layout.addLayout(named_layout)

        self.add_le = qg.QLineEdit()
        named_layout.layout().addWidget(self.add_le)

        

#-----------------Add, remove buttons ----------------------#
        button_layout = qg.QHBoxLayout() 
        main_layout.addLayout(button_layout)

        add_button=  qg.QPushButton("Add")
        rem_button=  qg.QPushButton("Remove")
    
        button_layout.layout().addWidget(add_button)
        button_layout.layout().addWidget(rem_button)
        
        
#-----------------First Splitter ----------------------#
        show_select_splitter=Splitter()
        showObject_widget.layout().addWidget(show_select_splitter)

#-----------------Load Info ----------------------#
        loadInfo_widget = self.createBasicWidget(spacing=10)
        self.layout().addWidget(loadInfo_widget)

        loadInfo_layout  = qg.QVBoxLayout()
        loadInfo_widget.layout().addLayout(loadInfo_layout)


        load_btn = qg.QPushButton("Load and Create")
        loadInfo_layout.layout().addWidget(load_btn)

#--------------------Test ------------------------#
        """test_widget = self.createBasicWidget(spacing=10)
        self.layout().addWidget(test_widget)

        self.info_lw = qg.QListWidget()

        test_widget.layout().addWidget(self.info_lw)"""

        #-----------------Connect ----------------------#

        add_button.clicked.connect(self.addInformation)
        rem_button.clicked.connect(self.removeInformation)
        load_btn.clicked.connect(self.loadInformation)
        #self.fillListInfo()



    def createBasicWidget(self,spacing=2,*args):
        basic_widget = qg.QWidget()
        basic_widget.setLayout(qg.QVBoxLayout())
        basic_widget.layout().setContentsMargins(0,0,0,0)
        basic_widget.layout().setSpacing(spacing)
        basic_widget.setSizePolicy(qg.QSizePolicy.Minimum,
                                    qg.QSizePolicy.Fixed)
        return basic_widget

    def getNameInfo(self):
        txt=str(self.add_le.text()).strip()
        return txt

    def addInformation(self):
        nameTest=self.getNameInfo()
        utils.exportInformation(self.getNameInfo(),"Add")
        self.add_le.clear()

    def removeInformation(self):
        nameTest=self.getNameInfo()
        utils.exportInformation(self.getNameInfo(),"Remove")
        self.add_le.clear()

    def fillListInfo(self):
        listNum=[str(i) for i in range (0,10)]
        print listNum
        self.info_lw.addItems(listNum)

    def loadInformation(self):
        utils.loadVertexInfo()

class Splitter(qg.QWidget):
    def __init__(self):
        qg.QWidget.__init__(self)
        self.setMinimumHeight(2)
        self.setLayout(qg.QHBoxLayout())
        self.layout().setContentsMargins(10,0,10,0)
        self.layout().setSpacing(0)
        self.layout().setAlignment(qc.Qt.AlignVCenter)

        main_line = qg.QFrame()
        main_line.setFrameStyle(qg.QFrame.HLine)
        self.layout().addWidget(main_line)




def create():
    global dialog 
    if dialog is None:
        dialog = baseWindow()
    dialog.show()

def delete():
    global dialog
    if dialog is None:
        return

    dialog.deleteLater()
    dialog = None